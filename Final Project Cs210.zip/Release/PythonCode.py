import re
import string


def displayMenu():      #Displays menus
    print("1: List of Items purchased")
    print("2: Number of time a Specific item was purchased")
    print("3: Histogram with all items purchased")
    print("4: Exit application")

def SpecificItem(v):
    f = open('U:\Final Project Cs210\Release\Input_File.txt', "r")      # opens file
    data = f.read()                                                     # Reads file 
    occurrences = data.count(v.capitalize())                            # counts number of time user item is in file
    print("Number of", v, ": ")
    f.close()                                                           # closes file
    return occurrences

def listItems():
    f = open('U:\Final Project Cs210\Release\Input_File.txt', "r")      # opens file
    data = f.read()                                                     # reads file to data
    str = data.split()                                                  # splits data into string
    str2 = []           #empty string

    for i in str:                                                       # appends names from string 1 to string 2 that aren't already there
        if i not in str2:
            str2.append(i)

    for i in range(0, len(str2)):                                       # counts each iteration of a name in the whole data set of string 1 and adds the count to the print function
        print("Number of", str2[i], "is:", str.count(str2[i]))

    f.close()

def Histogram():               
   
    dictionary = {}
    readFile = open('U:\Final Project Cs210\Release\Input_File.txt', "r")      # opens file
    data = readFile.read()                                                     # reads file to data
    str = data.split()                                                  # splits data into string
    str2 = []           #empty string

    for i in str:                                                       # appends names from string 1 to string 2 that aren't already there
        if i not in str2:
            str2.append(i)

    for i in range(0, len(str2)):                                       # counts each iteration of a name in the whole data set of string 1 and adds the count to the print function and write to dictionary
        dictionary[str2[i]] = str.count(str2[i])
    readFile.close()

    with open("U:\Final Project Cs210\Release\Output_File.txt", "w") as writeFile:     #takes dictionary and writes it to file with space inbetween item and number
        for key, value in dictionary.items():
            writeFile.write('%s %s\n' % (key,value))
    
    with open("U:\Final Project Cs210\Release\Output_File.txt", "r") as writeFile:  #prints the histogram
        for line in writeFile:
            for word in line.split():
                if word.isdigit()== True:       #checks if word is digit
                    converted_num = int(word)
                    print (converted_num * "*")     #converts num to symbol
                else:
                    print(word.ljust(15), end =" ") #makes histogram a bit neater
                
            